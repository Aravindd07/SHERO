-- Create storage bucket for SOS recordings
INSERT INTO storage.buckets (id, name, public) VALUES ('sos-recordings', 'sos-recordings', true);

-- Create storage policies for SOS recordings
CREATE POLICY "Anyone can upload SOS recordings" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'sos-recordings');
CREATE POLICY "Anyone can view SOS recordings" ON storage.objects FOR SELECT USING (bucket_id = 'sos-recordings');