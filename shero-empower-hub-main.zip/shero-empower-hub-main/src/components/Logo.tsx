import { Shield } from "lucide-react";

interface LogoProps {
  size?: "sm" | "md" | "lg";
  showTagline?: boolean;
}

const Logo = ({ size = "md", showTagline = false }: LogoProps) => {
  const sizes = {
    sm: { icon: 24, text: "text-xl" },
    md: { icon: 32, text: "text-3xl" },
    lg: { icon: 48, text: "text-5xl" },
  };

  return (
    <div className="flex flex-col items-center gap-1">
      <div className="flex items-center gap-2">
        <div className="gradient-primary p-2 rounded-xl shadow-glow">
          <Shield className="text-primary-foreground" size={sizes[size].icon} />
        </div>
        <span className={`${sizes[size].text} font-black tracking-tight text-gradient`}>
          SHERO
        </span>
      </div>
      {showTagline && (
        <p className="text-sm text-muted-foreground font-medium mt-1">
          Because Every SHE Deserves to Be a HERO
        </p>
      )}
    </div>
  );
};

export default Logo;
