import { useState, useEffect, useRef, useCallback } from "react";
import { AlertTriangle, Mic, MicOff, Phone, StopCircle, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

interface SOSButtonProps {
  sosNumber?: string;
}

const SOSButton = ({ sosNumber }: SOSButtonProps) => {
  const [isActivated, setIsActivated] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [countdown, setCountdown] = useState<number | null>(null);
  
  const recognitionRef = useRef<any>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const streamRef = useRef<MediaStream | null>(null);

  const getEmergencyNumber = useCallback(() => {
    const userData = localStorage.getItem('shero_user');
    if (userData) {
      const parsed = JSON.parse(userData);
      return parsed.sosNumber || sosNumber;
    }
    return sosNumber;
  }, [sosNumber]);

  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'en-US';

      recognition.onresult = (event: any) => {
        const transcript = Array.from(event.results)
          .map((result: any) => result[0].transcript)
          .join('')
          .toLowerCase();

        console.log('Voice detected:', transcript);

        const emergencyKeywords = ['help', 'sos', 'save me', 'please help', 'emergency', 'danger', 'bachao'];
        const hasEmergency = emergencyKeywords.some(keyword => transcript.includes(keyword));

        if (hasEmergency && !isActivated) {
          triggerSOS('voice');
        }
      };

      recognition.onerror = (event: any) => {
        if (event.error === 'not-allowed') {
          toast({
            title: "Microphone Permission Required",
            description: "Please allow microphone access for voice SOS",
            variant: "destructive",
          });
          setIsListening(false);
        }
      };

      recognition.onend = () => {
        if (isListening) {
          try { recognition.start(); } catch (e) {}
        }
      };

      recognitionRef.current = recognition;
    }

    return () => {
      if (recognitionRef.current) {
        try { recognitionRef.current.stop(); } catch (e) {}
      }
    };
  }, [isListening, isActivated]);

  const startListening = async () => {
    try {
      await navigator.mediaDevices.getUserMedia({ audio: true });
      if (recognitionRef.current) {
        recognitionRef.current.start();
        setIsListening(true);
        toast({
          title: "🎤 Voice SOS Active",
          description: "Say 'Help', 'SOS', or 'Save me' to trigger emergency",
        });
      }
    } catch (error) {
      toast({
        title: "Microphone Access Required",
        description: "Please allow microphone access for voice SOS",
        variant: "destructive",
      });
    }
  };

  const stopListening = () => {
    if (recognitionRef.current) {
      try { recognitionRef.current.stop(); } catch (e) {}
    }
    setIsListening(false);
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      streamRef.current = stream;
      const mediaRecorder = new MediaRecorder(stream, { mimeType: 'video/webm' });
      mediaRecorderRef.current = mediaRecorder;
      chunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) chunksRef.current.push(event.data);
      };

      mediaRecorder.onstop = async () => {
        const blob = new Blob(chunksRef.current, { type: 'video/webm' });
        await uploadRecording(blob);
      };

      mediaRecorder.start(1000);
      setIsRecording(true);
      toast({ title: "📹 Recording Started", description: "Video evidence is being captured" });
    } catch (error) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        streamRef.current = stream;
        const mediaRecorder = new MediaRecorder(stream);
        mediaRecorderRef.current = mediaRecorder;
        chunksRef.current = [];

        mediaRecorder.ondataavailable = (event) => {
          if (event.data.size > 0) chunksRef.current.push(event.data);
        };

        mediaRecorder.onstop = async () => {
          const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
          await uploadRecording(blob);
        };

        mediaRecorder.start(1000);
        setIsRecording(true);
        toast({ title: "🎙️ Audio Recording Started", description: "Audio evidence is being captured" });
      } catch (audioError) {
        console.error('Recording error:', audioError);
      }
    }
  };

  const uploadRecording = async (blob: Blob) => {
    try {
      const fileName = `sos_${Date.now()}.webm`;
      const { error } = await supabase.storage.from('sos-recordings').upload(fileName, blob, { contentType: blob.type });
      if (error) { console.error('Upload error:', error); return; }
      const { data: urlData } = supabase.storage.from('sos-recordings').getPublicUrl(fileName);
      console.log('Recording uploaded:', urlData.publicUrl);
    } catch (error) {
      console.error('Upload failed:', error);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      if (streamRef.current) streamRef.current.getTracks().forEach(track => track.stop());
      setIsRecording(false);
    }
  };

  const sendEmergencyAlerts = (lat: number, lng: number, emergencyNumber: string) => {
    const locationLink = `https://www.google.com/maps?q=${lat},${lng}`;
    const message = `🚨 EMERGENCY SOS from SHERO App!\n\nI need immediate help!\n\n📍 My Location: ${locationLink}\n\nPlease call me or come to my location immediately!`;
    const cleanNumber = emergencyNumber.replace(/\D/g, '');
    const indianNumber = cleanNumber.startsWith('91') ? cleanNumber : `91${cleanNumber}`;

    const actionsDiv = document.createElement('div');
    actionsDiv.id = 'sos-actions';
    actionsDiv.innerHTML = `
      <div style="position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);z-index:9999;background:white;padding:24px;border-radius:16px;box-shadow:0 25px 50px -12px rgba(0,0,0,0.25);max-width:320px;width:90%;">
        <h2 style="color:#dc2626;font-size:20px;font-weight:bold;margin-bottom:16px;text-align:center;">🚨 SOS ACTIVATED</h2>
        <p style="color:#374151;margin-bottom:20px;text-align:center;font-size:14px;">Tap below to contact your emergency number:</p>
        <div style="display:flex;flex-direction:column;gap:12px;">
          <a href="tel:${cleanNumber}" style="background:#dc2626;color:white;padding:14px;border-radius:12px;text-align:center;text-decoration:none;font-weight:600;">📞 CALL NOW</a>
          <a href="sms:${cleanNumber}?body=${encodeURIComponent(message)}" style="background:#2563eb;color:white;padding:14px;border-radius:12px;text-align:center;text-decoration:none;font-weight:600;">💬 Send SMS</a>
          <a href="https://wa.me/${indianNumber}?text=${encodeURIComponent(message)}" target="_blank" style="background:#22c55e;color:white;padding:14px;border-radius:12px;text-align:center;text-decoration:none;font-weight:600;">📱 WhatsApp Alert</a>
          <button onclick="document.getElementById('sos-actions').remove()" style="background:#6b7280;color:white;padding:12px;border-radius:12px;border:none;cursor:pointer;font-weight:600;">✓ Done</button>
        </div>
      </div>
      <div style="position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:9998;" onclick="document.getElementById('sos-actions').remove()"></div>
    `;
    document.body.appendChild(actionsDiv);
  };

  const triggerSOS = async (triggerType: string) => {
    if (isActivated) return;
    setIsActivated(true);
    setCountdown(3);

    for (let i = 3; i > 0; i--) {
      setCountdown(i);
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
    setCountdown(null);

    startRecording();

    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const lat = position.coords.latitude;
          const lng = position.coords.longitude;
          
          const userData = localStorage.getItem('shero_user');
          const userId = userData ? JSON.parse(userData).id || 'anonymous' : 'anonymous';
          
          await supabase.from('sos_logs').insert({
            user_id: userId,
            trigger_type: triggerType,
            location: `${lat},${lng}`,
            latitude: lat,
            longitude: lng,
          });

          toast({ title: "🚨 SOS ACTIVATED", description: "Emergency mode active!", variant: "destructive" });

          const emergencyNumber = getEmergencyNumber();
          if (emergencyNumber) {
            sendEmergencyAlerts(lat, lng, emergencyNumber);
          } else {
            toast({ title: "No Emergency Contact", description: "Please set up your emergency contact", variant: "destructive" });
          }
        },
        () => {
          const emergencyNumber = getEmergencyNumber();
          if (emergencyNumber) sendEmergencyAlerts(0, 0, emergencyNumber);
        },
        { enableHighAccuracy: true, timeout: 5000 }
      );
    }

    setTimeout(() => deactivateSOS(), 60000);
  };

  const deactivateSOS = () => {
    setIsActivated(false);
    stopRecording();
    const actionsDiv = document.getElementById('sos-actions');
    if (actionsDiv) actionsDiv.remove();
  };

  const handleSOS = () => {
    if (isActivated) deactivateSOS();
    else triggerSOS('manual');
  };

  return (
    <>
      <div className="fixed top-20 right-4 z-50">
        <Button
          variant={isListening ? "destructive" : "outline"}
          size="sm"
          onClick={isListening ? stopListening : startListening}
          className="gap-2 shadow-lg bg-card"
        >
          {isListening ? <><MicOff className="w-4 h-4" /><span className="hidden sm:inline">Stop Voice</span></> : <><Mic className="w-4 h-4" /><span className="hidden sm:inline">Voice SOS</span></>}
        </Button>
      </div>

      {isRecording && (
        <div className="fixed top-20 left-4 z-50">
          <Button variant="destructive" size="sm" onClick={stopRecording} className="gap-2 animate-pulse">
            <StopCircle className="w-4 h-4" /><span className="hidden sm:inline">Recording...</span>
          </Button>
        </div>
      )}

      {countdown !== null && (
        <div className="fixed inset-0 z-[100] bg-destructive/90 flex items-center justify-center">
          <div className="text-center text-primary-foreground">
            <p className="text-xl mb-4">SOS Activating in...</p>
            <span className="text-9xl font-bold animate-pulse">{countdown}</span>
            <p className="mt-4">Tap SOS again to cancel</p>
          </div>
        </div>
      )}

      <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-2 items-end">
        {isActivated && (
          <div className="flex gap-2 mb-2 animate-fade-in">
            <Button variant="outline" size="icon" onClick={() => { const n = getEmergencyNumber(); if (n) window.location.href = `tel:${n}`; }} className="bg-card shadow-lg h-12 w-12">
              <Phone className="w-5 h-5" />
            </Button>
            <Button variant="outline" size="icon" onClick={deactivateSOS} className="bg-card shadow-lg h-12 w-12">
              <X className="w-5 h-5" />
            </Button>
          </div>
        )}
        
        <Button
          variant="sos"
          size="xl"
          onClick={handleSOS}
          className={`rounded-full w-20 h-20 flex flex-col gap-1 shadow-glow transition-all duration-300 ${isActivated ? "animate-pulse scale-110 ring-4 ring-destructive/50" : ""} ${isListening ? "ring-4 ring-accent ring-offset-2" : ""}`}
        >
          <AlertTriangle size={28} />
          <span className="text-xs font-bold">{isActivated ? "STOP" : "SOS"}</span>
        </Button>
      </div>
    </>
  );
};

export default SOSButton;
