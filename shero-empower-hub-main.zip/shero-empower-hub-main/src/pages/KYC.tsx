import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import Logo from "@/components/Logo";
import { toast } from "@/hooks/use-toast";
import { Upload, Camera, CheckCircle, AlertTriangle, ArrowRight, Shield, User } from "lucide-react";

const KYC = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [isVerifying, setIsVerifying] = useState(false);
  const [aadhaarImage, setAadhaarImage] = useState<string | null>(null);
  const [selfieImage, setSelfieImage] = useState<string | null>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, type: "aadhaar" | "selfie") => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (type === "aadhaar") {
          setAadhaarImage(reader.result as string);
        } else {
          setSelfieImage(reader.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleVerify = () => {
    if (!aadhaarImage || !selfieImage) {
      toast({
        title: "Missing Documents",
        description: "Please upload both Aadhaar card and selfie",
        variant: "destructive",
      });
      return;
    }

    setIsVerifying(true);

    // Simulate AI verification
    setTimeout(() => {
      // In production: Use AI for face matching and gender detection
      toast({
        title: "Verification Successful! ✅",
        description: "Your identity has been verified. Welcome to SHERO!",
      });

      // Update user data
      const userData = JSON.parse(localStorage.getItem("shero_user") || "{}");
      userData.kycVerified = true;
      localStorage.setItem("shero_user", JSON.stringify(userData));

      setIsVerifying(false);
      navigate("/profile-setup");
    }, 3000);
  };

  return (
    <div className="min-h-screen gradient-soft p-4">
      <div className="container mx-auto max-w-2xl py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <Logo size="md" />
          <h1 className="text-3xl font-bold mt-6 mb-2">Identity Verification</h1>
          <p className="text-muted-foreground">
            We verify that every SHERO member is a real woman for your safety
          </p>
        </div>

        {/* Progress Steps */}
        <div className="flex items-center justify-center gap-4 mb-10">
          {[1, 2, 3].map((s) => (
            <div key={s} className="flex items-center gap-2">
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center font-bold transition-all ${
                  step >= s
                    ? "gradient-primary text-primary-foreground shadow-glow"
                    : "bg-muted text-muted-foreground"
                }`}
              >
                {step > s ? <CheckCircle className="w-5 h-5" /> : s}
              </div>
              {s < 3 && (
                <div
                  className={`w-12 h-1 rounded-full ${
                    step > s ? "gradient-primary" : "bg-muted"
                  }`}
                />
              )}
            </div>
          ))}
        </div>

        {/* Verification Card */}
        <div className="bg-card rounded-3xl shadow-soft p-8 border border-border">
          {step === 1 && (
            <div className="space-y-6">
              <div className="flex items-center gap-3 p-4 bg-primary/10 rounded-xl">
                <Shield className="w-8 h-8 text-primary" />
                <div>
                  <h3 className="font-semibold">Why we verify?</h3>
                  <p className="text-sm text-muted-foreground">
                    SHERO is a safe space exclusively for women. Verification ensures everyone's safety.
                  </p>
                </div>
              </div>

              <div className="space-y-4">
                <Label className="text-base font-semibold">Upload Aadhaar Card</Label>
                <div
                  className={`border-2 border-dashed rounded-2xl p-8 text-center transition-all ${
                    aadhaarImage ? "border-primary bg-primary/5" : "border-border hover:border-primary/50"
                  }`}
                >
                  {aadhaarImage ? (
                    <div className="space-y-4">
                      <img
                        src={aadhaarImage}
                        alt="Aadhaar"
                        className="max-h-48 mx-auto rounded-lg"
                      />
                      <p className="text-sm text-primary font-medium">Aadhaar uploaded ✓</p>
                    </div>
                  ) : (
                    <label className="cursor-pointer block">
                      <Upload className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                      <p className="font-medium mb-2">Click to upload Aadhaar card</p>
                      <p className="text-sm text-muted-foreground">
                        PNG, JPG up to 10MB
                      </p>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => handleFileUpload(e, "aadhaar")}
                        className="hidden"
                      />
                    </label>
                  )}
                </div>
              </div>

              <Button
                variant="hero"
                size="lg"
                className="w-full"
                onClick={() => aadhaarImage && setStep(2)}
                disabled={!aadhaarImage}
              >
                Continue
                <ArrowRight className="w-5 h-5" />
              </Button>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6">
              <div className="flex items-center gap-3 p-4 bg-accent/10 rounded-xl">
                <Camera className="w-8 h-8 text-accent" />
                <div>
                  <h3 className="font-semibold">Take a Selfie</h3>
                  <p className="text-sm text-muted-foreground">
                    Our AI will match your selfie with your Aadhaar photo
                  </p>
                </div>
              </div>

              <div className="space-y-4">
                <Label className="text-base font-semibold">Upload Your Selfie</Label>
                <div
                  className={`border-2 border-dashed rounded-2xl p-8 text-center transition-all ${
                    selfieImage ? "border-primary bg-primary/5" : "border-border hover:border-primary/50"
                  }`}
                >
                  {selfieImage ? (
                    <div className="space-y-4">
                      <img
                        src={selfieImage}
                        alt="Selfie"
                        className="w-48 h-48 mx-auto rounded-full object-cover"
                      />
                      <p className="text-sm text-primary font-medium">Selfie uploaded ✓</p>
                    </div>
                  ) : (
                    <label className="cursor-pointer block">
                      <User className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                      <p className="font-medium mb-2">Click to upload selfie</p>
                      <p className="text-sm text-muted-foreground">
                        Make sure your face is clearly visible
                      </p>
                      <input
                        type="file"
                        accept="image/*"
                        capture="user"
                        onChange={(e) => handleFileUpload(e, "selfie")}
                        className="hidden"
                      />
                    </label>
                  )}
                </div>
              </div>

              <div className="flex gap-4">
                <Button variant="outline" size="lg" onClick={() => setStep(1)} className="flex-1">
                  Back
                </Button>
                <Button
                  variant="hero"
                  size="lg"
                  className="flex-1"
                  onClick={() => selfieImage && setStep(3)}
                  disabled={!selfieImage}
                >
                  Continue
                  <ArrowRight className="w-5 h-5" />
                </Button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-6">
              <div className="text-center">
                <h3 className="text-xl font-bold mb-2">Review & Verify</h3>
                <p className="text-muted-foreground">
                  Please review your documents before verification
                </p>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-muted/50 rounded-xl p-4 text-center">
                  <p className="text-sm font-medium mb-3">Aadhaar Card</p>
                  <img
                    src={aadhaarImage!}
                    alt="Aadhaar"
                    className="max-h-32 mx-auto rounded-lg"
                  />
                </div>
                <div className="bg-muted/50 rounded-xl p-4 text-center">
                  <p className="text-sm font-medium mb-3">Your Selfie</p>
                  <img
                    src={selfieImage!}
                    alt="Selfie"
                    className="w-32 h-32 mx-auto rounded-full object-cover"
                  />
                </div>
              </div>

              <div className="p-4 bg-accent/10 rounded-xl">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-accent mt-0.5" />
                  <div className="text-sm">
                    <p className="font-medium">AI Verification</p>
                    <p className="text-muted-foreground">
                      Our AI will verify that you are a woman and match your selfie with your Aadhaar photo. 
                      This ensures SHERO remains a safe space for all women.
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex gap-4">
                <Button variant="outline" size="lg" onClick={() => setStep(2)} className="flex-1">
                  Back
                </Button>
                <Button
                  variant="hero"
                  size="lg"
                  className="flex-1"
                  onClick={handleVerify}
                  disabled={isVerifying}
                >
                  {isVerifying ? (
                    <>
                      <div className="w-5 h-5 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                      Verifying...
                    </>
                  ) : (
                    <>
                      Verify Identity
                      <CheckCircle className="w-5 h-5" />
                    </>
                  )}
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default KYC;
