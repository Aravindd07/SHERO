import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Landing from "./Landing";

const Index = () => {
  const navigate = useNavigate();

  useEffect(() => {
    // Check if user is already logged in
    const userData = localStorage.getItem("shero_user");
    if (userData) {
      const user = JSON.parse(userData);
      if (user.setupComplete) {
        navigate("/dashboard");
      }
    }
  }, [navigate]);

  return <Landing />;
};

export default Index;
