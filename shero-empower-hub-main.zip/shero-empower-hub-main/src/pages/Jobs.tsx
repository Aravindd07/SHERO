import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import Logo from "@/components/Logo";
import SOSButton from "@/components/SOSButton";
import {
  Briefcase,
  MapPin,
  Clock,
  Building,
  Search,
  Filter,
  ArrowLeft,
  ExternalLink,
  DollarSign,
} from "lucide-react";

const Jobs = () => {
  const [user, setUser] = useState<any>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedType, setSelectedType] = useState("all");

  useEffect(() => {
    const userData = localStorage.getItem("shero_user");
    if (userData) {
      setUser(JSON.parse(userData));
    }
  }, []);

  const jobs = [
    {
      id: 1,
      title: "Software Developer",
      company: "TCS",
      location: "Bangalore",
      type: "Full-time",
      salary: "₹8-12 LPA",
      posted: "2 days ago",
      description: "Looking for passionate software developers to join our team.",
      requirements: ["React", "Node.js", "3+ years experience"],
    },
    {
      id: 2,
      title: "Marketing Executive",
      company: "Infosys",
      location: "Bangalore",
      type: "Full-time",
      salary: "₹5-8 LPA",
      posted: "1 day ago",
      description: "Drive marketing initiatives and brand awareness.",
      requirements: ["Marketing degree", "2+ years experience"],
    },
    {
      id: 3,
      title: "Data Analyst",
      company: "Wipro",
      location: "Bangalore",
      type: "Full-time",
      salary: "₹6-10 LPA",
      posted: "3 days ago",
      description: "Analyze data to drive business decisions.",
      requirements: ["SQL", "Python", "Data visualization"],
    },
    {
      id: 4,
      title: "HR Manager",
      company: "Accenture",
      location: "Bangalore",
      type: "Full-time",
      salary: "₹10-15 LPA",
      posted: "5 hours ago",
      description: "Lead HR initiatives and team management.",
      requirements: ["HR certification", "5+ years experience"],
    },
    {
      id: 5,
      title: "UX Designer",
      company: "Amazon",
      location: "Hyderabad",
      type: "Full-time",
      salary: "₹12-18 LPA",
      posted: "1 day ago",
      description: "Design user experiences for millions of customers.",
      requirements: ["Figma", "UI/UX certification", "Portfolio"],
    },
    {
      id: 6,
      title: "Content Writer",
      company: "Flipkart",
      location: "Bangalore",
      type: "Part-time",
      salary: "₹3-5 LPA",
      posted: "4 days ago",
      description: "Create engaging content for our platform.",
      requirements: ["Excellent writing skills", "SEO knowledge"],
    },
    {
      id: 7,
      title: "Product Manager",
      company: "Google",
      location: "Bangalore",
      type: "Full-time",
      salary: "₹25-35 LPA",
      posted: "2 days ago",
      description: "Lead product development and strategy.",
      requirements: ["MBA", "5+ years PM experience"],
    },
    {
      id: 8,
      title: "Customer Support",
      company: "Swiggy",
      location: "Chennai",
      type: "Remote",
      salary: "₹2-4 LPA",
      posted: "6 hours ago",
      description: "Provide excellent customer service.",
      requirements: ["Good communication", "Problem-solving skills"],
    },
  ];

  const filteredJobs = jobs.filter((job) => {
    const matchesSearch =
      job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      job.company.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = selectedType === "all" || job.type === selectedType;
    return matchesSearch && matchesType;
  });

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Navigation */}
      <nav className="sticky top-0 z-40 bg-card/80 backdrop-blur-lg border-b border-border">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link to="/dashboard">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <Logo size="sm" />
          </div>
        </div>
      </nav>

      {/* Header */}
      <section className="gradient-soft py-8 px-4">
        <div className="container mx-auto">
          <h1 className="text-3xl font-bold mb-2">
            Find Your <span className="text-gradient">Dream Job</span>
          </h1>
          <p className="text-muted-foreground flex items-center gap-2">
            <MapPin className="w-4 h-4" />
            {user?.profile?.currentLocation || "Near you"}
          </p>
        </div>
      </section>

      <div className="container mx-auto px-4 py-6">
        {/* Search & Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              placeholder="Search jobs, companies..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-12"
            />
          </div>
          <div className="flex gap-2">
            {["all", "Full-time", "Part-time", "Remote"].map((type) => (
              <Button
                key={type}
                variant={selectedType === type ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedType(type)}
              >
                {type === "all" ? "All" : type}
              </Button>
            ))}
          </div>
        </div>

        {/* Jobs List */}
        <div className="space-y-4">
          {filteredJobs.map((job) => (
            <div
              key={job.id}
              className="bg-card p-6 rounded-xl border border-border hover:border-primary/50 hover:shadow-soft transition-all"
            >
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="font-bold text-xl mb-1">{job.title}</h3>
                  <p className="text-muted-foreground flex items-center gap-2">
                    <Building className="w-4 h-4" />
                    {job.company}
                  </p>
                </div>
                <span className="text-xs font-medium bg-primary/10 text-primary px-3 py-1 rounded-full">
                  {job.type}
                </span>
              </div>

              <p className="text-muted-foreground mb-4">{job.description}</p>

              <div className="flex flex-wrap gap-2 mb-4">
                {job.requirements.map((req, idx) => (
                  <span
                    key={idx}
                    className="text-xs bg-muted px-2 py-1 rounded-full"
                  >
                    {req}
                  </span>
                ))}
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <MapPin className="w-4 h-4" />
                    {job.location}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    {job.posted}
                  </span>
                  <span className="flex items-center gap-1 text-primary font-semibold">
                    <DollarSign className="w-4 h-4" />
                    {job.salary}
                  </span>
                </div>
                <Button className="gap-2">
                  Apply Now
                  <ExternalLink className="w-4 h-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>

        {filteredJobs.length === 0 && (
          <div className="text-center py-12">
            <Briefcase className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-xl font-bold mb-2">No jobs found</h3>
            <p className="text-muted-foreground">
              Try adjusting your search or filters
            </p>
          </div>
        )}
      </div>

      <SOSButton sosNumber={user?.sosNumber} />
    </div>
  );
};

export default Jobs;
