import { useState, useEffect } from "react";
import { ArrowLeft, Video, Mic, Calendar, MapPin, Play } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { useNavigate } from "react-router-dom";

interface SOSLog {
  id: string;
  trigger_type: string;
  location: string | null;
  latitude: number | null;
  longitude: number | null;
  recording_url: string | null;
  created_at: string;
}

interface Recording {
  name: string;
  url: string;
  created_at: string;
}

const SOSHistory = () => {
  const navigate = useNavigate();
  const [logs, setLogs] = useState<SOSLog[]>([]);
  const [recordings, setRecordings] = useState<Recording[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      // Fetch SOS logs
      const userData = localStorage.getItem('shero_user');
      const userId = userData ? JSON.parse(userData).id || 'anonymous' : 'anonymous';
      
      const { data: logsData } = await supabase
        .from('sos_logs')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      if (logsData) setLogs(logsData);

      // Fetch recordings from storage
      const { data: files } = await supabase.storage.from('sos-recordings').list();
      
      if (files) {
        const recordingsList = files.map(file => ({
          name: file.name,
          url: supabase.storage.from('sos-recordings').getPublicUrl(file.name).data.publicUrl,
          created_at: file.created_at || new Date().toISOString()
        }));
        setRecordings(recordingsList);
      }
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-40 bg-background/95 backdrop-blur border-b border-border">
        <div className="container mx-auto px-4 py-4 flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => navigate('/dashboard')}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-xl font-bold">SOS History</h1>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6 space-y-6">
        {/* Recordings Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Video className="w-5 h-5 text-primary" />
              Recordings
            </CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <p className="text-muted-foreground">Loading...</p>
            ) : recordings.length === 0 ? (
              <p className="text-muted-foreground">No recordings yet</p>
            ) : (
              <div className="grid gap-4">
                {recordings.map((recording, index) => (
                  <div key={index} className="border border-border rounded-lg p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        {recording.name.includes('video') || recording.name.endsWith('.webm') ? (
                          <Video className="w-4 h-4 text-destructive" />
                        ) : (
                          <Mic className="w-4 h-4 text-accent" />
                        )}
                        <span className="text-sm font-medium truncate max-w-[200px]">
                          {recording.name}
                        </span>
                      </div>
                      <a
                        href={recording.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-1 text-primary hover:underline text-sm"
                      >
                        <Play className="w-4 h-4" /> Play
                      </a>
                    </div>
                    <video
                      src={recording.url}
                      controls
                      className="w-full rounded-lg max-h-[300px] bg-muted"
                    />
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* SOS Logs Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-primary" />
              SOS Incident Logs
            </CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <p className="text-muted-foreground">Loading...</p>
            ) : logs.length === 0 ? (
              <p className="text-muted-foreground">No SOS incidents recorded</p>
            ) : (
              <div className="space-y-3">
                {logs.map((log) => (
                  <div key={log.id} className="border border-border rounded-lg p-4 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-semibold capitalize bg-destructive/10 text-destructive px-2 py-1 rounded">
                        {log.trigger_type} trigger
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {formatDate(log.created_at)}
                      </span>
                    </div>
                    {log.latitude && log.longitude && (
                      <a
                        href={`https://www.google.com/maps?q=${log.latitude},${log.longitude}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-1 text-sm text-primary hover:underline"
                      >
                        <MapPin className="w-4 h-4" />
                        View Location
                      </a>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
};

export default SOSHistory;
