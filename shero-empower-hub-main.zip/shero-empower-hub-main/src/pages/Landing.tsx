import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import Logo from "@/components/Logo";
import { Shield, Heart, Users, Briefcase, BookOpen, Phone, ArrowRight, Star, CheckCircle } from "lucide-react";

const Landing = () => {
  const features = [
    {
      icon: <Shield className="w-8 h-8" />,
      title: "Safety First",
      description: "24/7 SOS system with voice activation, live location sharing, and instant alerts.",
    },
    {
      icon: <Briefcase className="w-8 h-8" />,
      title: "Job Opportunities",
      description: "Curated job listings tailored to your skills and location.",
    },
    {
      icon: <Users className="w-8 h-8" />,
      title: "Mentorship",
      description: "Connect with mentors who guide you through career and personal growth.",
    },
    {
      icon: <BookOpen className="w-8 h-8" />,
      title: "Skill Development",
      description: "Access courses and resources to upskill and achieve your dreams.",
    },
  ];

  const stats = [
    { number: "10K+", label: "Women Empowered" },
    { number: "500+", label: "Mentors" },
    { number: "1000+", label: "Jobs Listed" },
    { number: "24/7", label: "Safety Support" },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-lg border-b border-border">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Logo size="sm" />
          <div className="flex items-center gap-4">
            <Link to="/auth">
              <Button variant="ghost">Login</Button>
            </Link>
            <Link to="/auth?signup=true">
              <Button variant="hero" size="sm">Get Started</Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4 gradient-soft min-h-[90vh] flex items-center">
        <div className="container mx-auto">
          <div className="max-w-4xl mx-auto text-center">
            <div className="animate-slide-up">
              <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-semibold mb-6">
                <Star className="w-4 h-4" />
                Empowering Women Everywhere
              </div>
              <h1 className="text-5xl md:text-7xl font-black mb-6 leading-tight">
                <span className="text-gradient">SHERO</span>
              </h1>
              <p className="text-2xl md:text-3xl font-semibold text-foreground/80 mb-4">
                Because Every <span className="text-primary">SHE</span> Deserves to Be a <span className="text-primary">HERO</span>
              </p>
              <p className="text-lg text-muted-foreground mb-10 max-w-2xl mx-auto">
                Your all-in-one platform for safety, career growth, mentorship, and community support. 
                Take control of your journey with confidence.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link to="/auth?signup=true">
                  <Button variant="hero" size="xl" className="w-full sm:w-auto">
                    Join SHERO Today
                    <ArrowRight className="w-5 h-5" />
                  </Button>
                </Link>
                <Link to="/auth">
                  <Button variant="outline" size="xl" className="w-full sm:w-auto">
                    Already a Member? Login
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-secondary">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center animate-fade-in" style={{ animationDelay: `${index * 0.1}s` }}>
                <div className="text-4xl md:text-5xl font-black text-primary-foreground mb-2">
                  {stat.number}
                </div>
                <div className="text-secondary-foreground/80 font-medium">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Everything You Need to <span className="text-gradient">Thrive</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              From safety to career advancement, SHERO has got you covered
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div
                key={index}
                className="bg-card p-8 rounded-2xl shadow-soft hover:shadow-glow transition-all duration-300 hover:-translate-y-2 border border-border group"
              >
                <div className="w-16 h-16 gradient-primary rounded-xl flex items-center justify-center text-primary-foreground mb-6 group-hover:scale-110 transition-transform">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SOS Feature Highlight */}
      <section className="py-24 px-4 gradient-soft">
        <div className="container mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center gap-2 bg-destructive/10 text-destructive px-4 py-2 rounded-full text-sm font-semibold mb-6">
                <Phone className="w-4 h-4" />
                Safety Feature
              </div>
              <h2 className="text-4xl md:text-5xl font-bold mb-6">
                Advanced <span className="text-primary">SOS System</span>
              </h2>
              <p className="text-lg text-muted-foreground mb-8">
                Our intelligent SOS system keeps you safe 24/7 with voice-activated emergency alerts, 
                automatic location sharing, and instant notification to your trusted contacts.
              </p>
              <ul className="space-y-4">
                {[
                  "Voice-activated emergency trigger",
                  "Automatic video recording",
                  "Live GPS location sharing",
                  "SMS, WhatsApp & Call alerts",
                ].map((item, index) => (
                  <li key={index} className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-primary" />
                    <span className="font-medium">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="flex justify-center">
              <div className="relative">
                <div className="w-64 h-64 gradient-primary rounded-full flex items-center justify-center shadow-glow animate-pulse-slow">
                  <Phone className="w-24 h-24 text-primary-foreground" />
                </div>
                <div className="absolute -top-4 -right-4 w-20 h-20 bg-destructive rounded-full flex items-center justify-center text-destructive-foreground font-bold shadow-lg">
                  SOS
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 px-4 bg-secondary">
        <div className="container mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-secondary-foreground">
            Ready to Become a <span className="text-primary">SHERO</span>?
          </h2>
          <p className="text-xl text-secondary-foreground/80 mb-10 max-w-2xl mx-auto">
            Join thousands of women who are already transforming their lives with SHERO.
          </p>
          <Link to="/auth?signup=true">
            <Button variant="hero" size="xl">
              Start Your Journey
              <ArrowRight className="w-5 h-5" />
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 border-t border-border">
        <div className="container mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <Logo size="sm" />
            <p className="text-muted-foreground text-sm">
              © 2024 SHERO. All rights reserved. Built with ❤️ for women everywhere.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Landing;
