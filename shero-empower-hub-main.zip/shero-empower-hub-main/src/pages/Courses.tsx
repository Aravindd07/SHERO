import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import Logo from "@/components/Logo";
import SOSButton from "@/components/SOSButton";
import {
  ArrowLeft,
  BookOpen,
  Play,
  Clock,
  Users,
  Star,
  Lock,
} from "lucide-react";

const Courses = () => {
  const upcomingCourses = [
    {
      id: 1,
      title: "Introduction to Programming",
      instructor: "VS Mohamed Yusuf",
      duration: "8 weeks",
      students: 1250,
      rating: 4.9,
      image: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=400&h=300&fit=crop",
      category: "Technology",
    },
    {
      id: 2,
      title: "Digital Marketing Fundamentals",
      instructor: "Ved Gupta",
      duration: "6 weeks",
      students: 890,
      rating: 4.8,
      image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&h=300&fit=crop",
      category: "Marketing",
    },
    {
      id: 3,
      title: "Leadership for Women",
      instructor: "Arvind S",
      duration: "4 weeks",
      students: 720,
      rating: 4.9,
      image: "https://images.unsplash.com/photo-1573164713714-d95e436ab8d6?w=400&h=300&fit=crop",
      category: "Leadership",
    },
    {
      id: 4,
      title: "Financial Literacy",
      instructor: "Expert Panel",
      duration: "5 weeks",
      students: 560,
      rating: 4.7,
      image: "https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=400&h=300&fit=crop",
      category: "Finance",
    },
    {
      id: 5,
      title: "Public Speaking Mastery",
      instructor: "Communication Expert",
      duration: "3 weeks",
      students: 430,
      rating: 4.8,
      image: "https://images.unsplash.com/photo-1475721027785-f74eccf877e2?w=400&h=300&fit=crop",
      category: "Communication",
    },
    {
      id: 6,
      title: "Entrepreneurship 101",
      instructor: "Business Leaders",
      duration: "10 weeks",
      students: 340,
      rating: 4.9,
      image: "https://images.unsplash.com/photo-1556761175-4b46a572b786?w=400&h=300&fit=crop",
      category: "Business",
    },
  ];

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Navigation */}
      <nav className="sticky top-0 z-40 bg-card/80 backdrop-blur-lg border-b border-border">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link to="/dashboard">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <Logo size="sm" />
          </div>
        </div>
      </nav>

      {/* Header */}
      <section className="gradient-soft py-8 px-4">
        <div className="container mx-auto">
          <h1 className="text-3xl font-bold mb-2">
            Skill Up with <span className="text-gradient">Courses</span>
          </h1>
          <p className="text-muted-foreground">
            Learn new skills and advance your career
          </p>
        </div>
      </section>

      <div className="container mx-auto px-4 py-6">
        {/* Coming Soon Banner */}
        <div className="bg-gradient-to-r from-primary/20 to-accent/20 rounded-2xl p-8 mb-8 text-center">
          <div className="w-20 h-20 gradient-primary rounded-full flex items-center justify-center mx-auto mb-4">
            <BookOpen className="w-10 h-10 text-primary-foreground" />
          </div>
          <h2 className="text-2xl font-bold mb-2">Courses Coming Soon!</h2>
          <p className="text-muted-foreground max-w-lg mx-auto mb-4">
            We're working on amazing courses to help you upskill and grow your career. 
            Get notified when we launch!
          </p>
          <Button variant="hero">
            Notify Me
          </Button>
        </div>

        {/* Preview Courses */}
        <h3 className="text-xl font-bold mb-6">Preview Upcoming Courses</h3>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {upcomingCourses.map((course) => (
            <div
              key={course.id}
              className="bg-card rounded-xl border border-border overflow-hidden group hover:shadow-soft transition-all"
            >
              <div className="relative">
                <img
                  src={course.image}
                  alt={course.title}
                  className="w-full h-48 object-cover"
                />
                <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="w-14 h-14 bg-white/20 backdrop-blur rounded-full flex items-center justify-center">
                    <Lock className="w-6 h-6 text-white" />
                  </div>
                </div>
                <span className="absolute top-3 left-3 bg-primary/90 text-primary-foreground text-xs px-2 py-1 rounded-full">
                  {course.category}
                </span>
              </div>
              <div className="p-4">
                <h4 className="font-bold text-lg mb-1">{course.title}</h4>
                <p className="text-sm text-muted-foreground mb-3">
                  by {course.instructor}
                </p>
                <div className="flex items-center justify-between text-sm text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    {course.duration}
                  </span>
                  <span className="flex items-center gap-1">
                    <Users className="w-4 h-4" />
                    {course.students}
                  </span>
                  <span className="flex items-center gap-1 text-accent">
                    <Star className="w-4 h-4 fill-current" />
                    {course.rating}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <SOSButton />
    </div>
  );
};

export default Courses;
