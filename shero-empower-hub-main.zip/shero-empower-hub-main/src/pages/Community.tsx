import { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import Logo from "@/components/Logo";
import SOSButton from "@/components/SOSButton";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import {
  ArrowLeft,
  Users,
  MessageCircle,
  Send,
  X,
  Check,
  UserPlus,
} from "lucide-react";

interface Community {
  id: string;
  name: string;
  description: string;
  image_url: string;
  member_count: number;
}

interface CommunityMessage {
  id: string;
  user_name: string;
  content: string;
  created_at: string;
}

const Community = () => {
  const [user, setUser] = useState<any>(null);
  const [communities, setCommunities] = useState<Community[]>([]);
  const [joinedCommunities, setJoinedCommunities] = useState<string[]>([]);
  const [selectedCommunity, setSelectedCommunity] = useState<Community | null>(null);
  const [messages, setMessages] = useState<CommunityMessage[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [isChatOpen, setIsChatOpen] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const userData = localStorage.getItem("shero_user");
    if (userData) {
      setUser(JSON.parse(userData));
    }
    fetchCommunities();
  }, []);

  useEffect(() => {
    if (user) {
      fetchJoinedCommunities();
    }
  }, [user]);

  useEffect(() => {
    if (selectedCommunity) {
      fetchMessages();
      
      const channel = supabase
        .channel('community-messages')
        .on(
          'postgres_changes',
          {
            event: 'INSERT',
            schema: 'public',
            table: 'community_messages',
            filter: `community_id=eq.${selectedCommunity.id}`,
          },
          (payload) => {
            setMessages((prev) => [...prev, payload.new as CommunityMessage]);
          }
        )
        .subscribe();

      return () => {
        supabase.removeChannel(channel);
      };
    }
  }, [selectedCommunity]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const fetchCommunities = async () => {
    const { data, error } = await supabase
      .from('communities')
      .select('*');
    
    if (error) {
      console.error('Error fetching communities:', error);
      return;
    }
    
    setCommunities(data || []);
  };

  const fetchJoinedCommunities = async () => {
    if (!user) return;
    
    const { data, error } = await supabase
      .from('community_members')
      .select('community_id')
      .eq('user_id', user.id || 'anonymous');
    
    if (error) {
      console.error('Error fetching joined communities:', error);
      return;
    }
    
    setJoinedCommunities(data?.map(m => m.community_id) || []);
  };

  const fetchMessages = async () => {
    if (!selectedCommunity) return;
    
    const { data, error } = await supabase
      .from('community_messages')
      .select('*')
      .eq('community_id', selectedCommunity.id)
      .order('created_at', { ascending: true })
      .limit(100);
    
    if (error) {
      console.error('Error fetching messages:', error);
      return;
    }
    
    setMessages(data || []);
  };

  const joinCommunity = async (communityId: string) => {
    if (!user) return;

    const { error } = await supabase
      .from('community_members')
      .insert({
        community_id: communityId,
        user_id: user.id || 'anonymous',
      });

    if (error) {
      toast({
        title: "Error",
        description: "Failed to join community",
        variant: "destructive",
      });
      return;
    }

    setJoinedCommunities([...joinedCommunities, communityId]);
    toast({
      title: "Joined!",
      description: "You've successfully joined the community",
    });
  };

  const openChat = (community: Community) => {
    if (!joinedCommunities.includes(community.id)) {
      toast({
        title: "Join First",
        description: "You need to join the community to chat",
        variant: "destructive",
      });
      return;
    }
    setSelectedCommunity(community);
    setIsChatOpen(true);
  };

  const sendMessage = async () => {
    if (!newMessage.trim() || !selectedCommunity || !user) return;

    const { error } = await supabase
      .from('community_messages')
      .insert({
        community_id: selectedCommunity.id,
        user_id: user.id || 'anonymous',
        user_name: user.name || 'Anonymous',
        content: newMessage,
      });

    if (error) {
      toast({
        title: "Error",
        description: "Failed to send message",
        variant: "destructive",
      });
      return;
    }

    setNewMessage("");
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Navigation */}
      <nav className="sticky top-0 z-40 bg-card/80 backdrop-blur-lg border-b border-border">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link to="/dashboard">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <Logo size="sm" />
          </div>
        </div>
      </nav>

      {/* Header */}
      <section className="gradient-soft py-8 px-4">
        <div className="container mx-auto">
          <h1 className="text-3xl font-bold mb-2">
            SHERO <span className="text-gradient">Community</span>
          </h1>
          <p className="text-muted-foreground">
            Connect, share, and grow with other SHEROs
          </p>
        </div>
      </section>

      <div className="container mx-auto px-4 py-6">
        <div className="grid md:grid-cols-2 gap-6">
          {communities.map((community) => {
            const isJoined = joinedCommunities.includes(community.id);
            return (
              <div
                key={community.id}
                className="bg-card rounded-xl border border-border overflow-hidden hover:shadow-soft transition-all"
              >
                <img
                  src={community.image_url}
                  alt={community.name}
                  className="w-full h-40 object-cover"
                />
                <div className="p-4">
                  <h3 className="font-bold text-xl mb-1">{community.name}</h3>
                  <p className="text-sm text-muted-foreground mb-3">
                    {community.description}
                  </p>
                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-1 text-sm text-muted-foreground">
                      <Users className="w-4 h-4" />
                      {community.member_count} members
                    </span>
                    <div className="flex gap-2">
                      {isJoined ? (
                        <>
                          <Button
                            variant="outline"
                            size="sm"
                            className="gap-1 text-green-600"
                            disabled
                          >
                            <Check className="w-4 h-4" />
                            Joined
                          </Button>
                          <Button
                            size="sm"
                            onClick={() => openChat(community)}
                            className="gap-1"
                          >
                            <MessageCircle className="w-4 h-4" />
                            Chat
                          </Button>
                        </>
                      ) : (
                        <Button
                          size="sm"
                          onClick={() => joinCommunity(community.id)}
                          className="gap-1"
                        >
                          <UserPlus className="w-4 h-4" />
                          Join
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Chat Modal */}
      {isChatOpen && selectedCommunity && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-end md:items-center justify-center p-4">
          <div className="bg-card w-full max-w-lg rounded-t-2xl md:rounded-2xl max-h-[80vh] flex flex-col">
            {/* Chat Header */}
            <div className="flex items-center justify-between p-4 border-b border-border">
              <div className="flex items-center gap-3">
                <img
                  src={selectedCommunity.image_url}
                  alt={selectedCommunity.name}
                  className="w-10 h-10 rounded-full object-cover"
                />
                <div>
                  <h3 className="font-bold">{selectedCommunity.name}</h3>
                  <p className="text-xs text-muted-foreground">
                    {selectedCommunity.member_count} members
                  </p>
                </div>
              </div>
              <Button variant="ghost" size="sm" onClick={() => setIsChatOpen(false)}>
                <X className="w-5 h-5" />
              </Button>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 min-h-[300px]">
              {messages.length === 0 && (
                <div className="text-center text-muted-foreground py-8">
                  <MessageCircle className="w-12 h-12 mx-auto mb-2 opacity-50" />
                  <p>Be the first to say hello!</p>
                </div>
              )}
              {messages.map((msg) => {
                const isMe = msg.user_name === (user?.name || 'Anonymous');
                return (
                  <div
                    key={msg.id}
                    className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-[80%] p-3 rounded-2xl ${
                        isMe
                          ? 'bg-primary text-primary-foreground rounded-br-sm'
                          : 'bg-muted rounded-bl-sm'
                      }`}
                    >
                      {!isMe && (
                        <p className="text-xs font-semibold mb-1">{msg.user_name}</p>
                      )}
                      <p className="text-sm">{msg.content}</p>
                    </div>
                  </div>
                );
              })}
              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <div className="p-4 border-t border-border">
              <div className="flex gap-2">
                <Input
                  placeholder="Type a message..."
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                />
                <Button onClick={sendMessage}>
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      <SOSButton />
    </div>
  );
};

export default Community;
