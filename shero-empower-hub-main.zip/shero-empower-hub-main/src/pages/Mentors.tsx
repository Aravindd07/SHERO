import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import Logo from "@/components/Logo";
import SOSButton from "@/components/SOSButton";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import {
  ArrowLeft,
  Star,
  MessageCircle,
  Send,
  X,
  User,
} from "lucide-react";

interface Mentor {
  id: string;
  name: string;
  role: string;
  image_url: string;
  bio: string;
  rating: number;
}

interface Message {
  id: string;
  content: string;
  sender_id: string;
  created_at: string;
}

const Mentors = () => {
  const [user, setUser] = useState<any>(null);
  const [mentors, setMentors] = useState<Mentor[]>([]);
  const [selectedMentor, setSelectedMentor] = useState<Mentor | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [isChatOpen, setIsChatOpen] = useState(false);

  useEffect(() => {
    const userData = localStorage.getItem("shero_user");
    if (userData) {
      setUser(JSON.parse(userData));
    }
    fetchMentors();
  }, []);

  useEffect(() => {
    if (selectedMentor && user) {
      fetchMessages();
      
      // Subscribe to real-time messages
      const channel = supabase
        .channel('mentor-messages')
        .on(
          'postgres_changes',
          {
            event: 'INSERT',
            schema: 'public',
            table: 'messages',
            filter: `mentor_id=eq.${selectedMentor.id}`,
          },
          (payload) => {
            setMessages((prev) => [...prev, payload.new as Message]);
          }
        )
        .subscribe();

      return () => {
        supabase.removeChannel(channel);
      };
    }
  }, [selectedMentor, user]);

  const fetchMentors = async () => {
    const { data, error } = await supabase
      .from('mentors')
      .select('*');
    
    if (error) {
      console.error('Error fetching mentors:', error);
      return;
    }
    
    setMentors(data || []);
  };

  const fetchMessages = async () => {
    if (!selectedMentor) return;
    
    const { data, error } = await supabase
      .from('messages')
      .select('*')
      .eq('mentor_id', selectedMentor.id)
      .order('created_at', { ascending: true });
    
    if (error) {
      console.error('Error fetching messages:', error);
      return;
    }
    
    setMessages(data || []);
  };

  const sendMessage = async () => {
    if (!newMessage.trim() || !selectedMentor || !user) return;

    const userId = user.id || 'anonymous';
    
    const { error } = await supabase
      .from('messages')
      .insert({
        sender_id: userId,
        receiver_id: selectedMentor.id,
        mentor_id: selectedMentor.id,
        content: newMessage,
      });

    if (error) {
      toast({
        title: "Error",
        description: "Failed to send message",
        variant: "destructive",
      });
      return;
    }

    setNewMessage("");
  };

  const openChat = (mentor: Mentor) => {
    setSelectedMentor(mentor);
    setIsChatOpen(true);
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Navigation */}
      <nav className="sticky top-0 z-40 bg-card/80 backdrop-blur-lg border-b border-border">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link to="/dashboard">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <Logo size="sm" />
          </div>
        </div>
      </nav>

      {/* Header */}
      <section className="gradient-soft py-8 px-4">
        <div className="container mx-auto">
          <h1 className="text-3xl font-bold mb-2">
            Your <span className="text-gradient">Mentors</span>
          </h1>
          <p className="text-muted-foreground">
            Connect with experts who can guide your journey
          </p>
        </div>
      </section>

      <div className="container mx-auto px-4 py-6">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {mentors.map((mentor) => (
            <div
              key={mentor.id}
              className="bg-card p-6 rounded-xl border border-border hover:border-primary/50 hover:shadow-soft transition-all"
            >
              <img
                src={mentor.image_url}
                alt={mentor.name}
                className="w-32 h-32 rounded-full mx-auto mb-4 object-cover border-4 border-primary/20"
              />
              <h3 className="font-bold text-xl text-center">{mentor.name}</h3>
              <p className="text-muted-foreground text-center mb-2">{mentor.role}</p>
              <div className="flex items-center justify-center gap-1 text-accent mb-4">
                <Star className="w-4 h-4 fill-current" />
                <span className="font-semibold">{mentor.rating}</span>
              </div>
              <p className="text-sm text-muted-foreground text-center mb-4">
                {mentor.bio}
              </p>
              <Button
                variant="default"
                className="w-full gap-2"
                onClick={() => openChat(mentor)}
              >
                <MessageCircle className="w-4 h-4" />
                Chat with {mentor.name.split(' ')[0]}
              </Button>
            </div>
          ))}
        </div>
      </div>

      {/* Chat Modal */}
      {isChatOpen && selectedMentor && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-end md:items-center justify-center p-4">
          <div className="bg-card w-full max-w-lg rounded-t-2xl md:rounded-2xl max-h-[80vh] flex flex-col">
            {/* Chat Header */}
            <div className="flex items-center justify-between p-4 border-b border-border">
              <div className="flex items-center gap-3">
                <img
                  src={selectedMentor.image_url}
                  alt={selectedMentor.name}
                  className="w-10 h-10 rounded-full object-cover"
                />
                <div>
                  <h3 className="font-bold">{selectedMentor.name}</h3>
                  <p className="text-xs text-green-500">Online</p>
                </div>
              </div>
              <Button variant="ghost" size="sm" onClick={() => setIsChatOpen(false)}>
                <X className="w-5 h-5" />
              </Button>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 min-h-[300px]">
              {messages.length === 0 && (
                <div className="text-center text-muted-foreground py-8">
                  <MessageCircle className="w-12 h-12 mx-auto mb-2 opacity-50" />
                  <p>Start a conversation with {selectedMentor.name}</p>
                </div>
              )}
              {messages.map((msg) => {
                const isMe = msg.sender_id === (user?.id || 'anonymous');
                return (
                  <div
                    key={msg.id}
                    className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-[80%] p-3 rounded-2xl ${
                        isMe
                          ? 'bg-primary text-primary-foreground rounded-br-sm'
                          : 'bg-muted rounded-bl-sm'
                      }`}
                    >
                      <p className="text-sm">{msg.content}</p>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Input */}
            <div className="p-4 border-t border-border">
              <div className="flex gap-2">
                <Input
                  placeholder="Type a message..."
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                />
                <Button onClick={sendMessage}>
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      <SOSButton sosNumber={user?.sosNumber} />
    </div>
  );
};

export default Mentors;
