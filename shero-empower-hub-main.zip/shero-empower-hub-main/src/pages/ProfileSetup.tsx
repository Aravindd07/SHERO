import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import Logo from "@/components/Logo";
import { toast } from "@/hooks/use-toast";
import {
  User,
  Phone,
  MapPin,
  GraduationCap,
  Briefcase,
  Languages,
  ArrowRight,
  CheckCircle,
  X,
} from "lucide-react";

const ProfileSetup = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [userType, setUserType] = useState<"student" | "professional" | null>(null);
  const [showMentorPopup, setShowMentorPopup] = useState(false);
  const [wantsMentor, setWantsMentor] = useState<boolean | null>(null);

  const [formData, setFormData] = useState({
    phone: "",
    age: "",
    address: "",
    currentLocation: "",
    education: "",
    qualifications: "",
    skills: [] as string[],
    languages: [] as string[],
    interests: [] as string[],
    workExperience: "",
    pastRoles: "",
    mentorProblems: "",
    mentorGuidance: [] as string[],
    mentorDetails: "",
  });

  const [newSkill, setNewSkill] = useState("");

  const skillOptions = [
    "Communication",
    "Leadership",
    "Problem Solving",
    "Data Analysis",
    "Design",
    "Marketing",
    "Sales",
    "Customer Service",
    "Programming",
    "Project Management",
  ];

  const languageOptions = ["English", "Hindi", "Tamil", "Telugu", "Bengali", "Marathi", "Gujarati", "Kannada"];
  const guidanceOptions = ["Career Growth", "Mental Health", "Confidence Building", "Learning Resources", "Job Preparation", "Personal Issues"];
  const interestOptions = ["Technology", "Healthcare", "Education", "Finance", "Marketing", "Design", "Operations", "HR"];

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const toggleArrayItem = (array: string[], item: string, key: string) => {
    const newArray = array.includes(item)
      ? array.filter((i) => i !== item)
      : [...array, item];
    setFormData({ ...formData, [key]: newArray });
  };

  const addSkill = () => {
    if (newSkill && !formData.skills.includes(newSkill)) {
      setFormData({ ...formData, skills: [...formData.skills, newSkill] });
      setNewSkill("");
    }
  };

  const handleSubmit = () => {
    setIsLoading(true);

    setTimeout(() => {
      const userData = JSON.parse(localStorage.getItem("shero_user") || "{}");
      userData.profileComplete = true;
      userData.profile = formData;
      userData.wantsMentor = wantsMentor;
      localStorage.setItem("shero_user", JSON.stringify(userData));

      toast({
        title: "Profile Complete! 🎉",
        description: "Welcome to SHERO. Let's set up your SOS contact.",
      });

      setIsLoading(false);
      navigate("/sos-setup");
    }, 1500);
  };

  return (
    <div className="min-h-screen gradient-soft p-4">
      <div className="container mx-auto max-w-2xl py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <Logo size="md" />
          <h1 className="text-3xl font-bold mt-6 mb-2">Complete Your Profile</h1>
          <p className="text-muted-foreground">Help us personalize your SHERO experience</p>
        </div>

        {/* Progress */}
        <div className="flex items-center justify-center gap-4 mb-10">
          {[1, 2, 3].map((s) => (
            <div key={s} className="flex items-center gap-2">
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center font-bold transition-all ${
                  step >= s ? "gradient-primary text-primary-foreground shadow-glow" : "bg-muted text-muted-foreground"
                }`}
              >
                {step > s ? <CheckCircle className="w-5 h-5" /> : s}
              </div>
              {s < 3 && <div className={`w-12 h-1 rounded-full ${step > s ? "gradient-primary" : "bg-muted"}`} />}
            </div>
          ))}
        </div>

        {/* Form Card */}
        <div className="bg-card rounded-3xl shadow-soft p-8 border border-border">
          {step === 1 && (
            <div className="space-y-6">
              <h2 className="text-xl font-bold flex items-center gap-2">
                <User className="w-5 h-5 text-primary" />
                Personal Information
              </h2>

              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Phone Number</Label>
                  <div className="relative">
                    <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                    <Input
                      name="phone"
                      placeholder="+91 XXXXX XXXXX"
                      value={formData.phone}
                      onChange={handleChange}
                      className="pl-12"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Age</Label>
                  <Input
                    name="age"
                    type="number"
                    placeholder="Your age"
                    value={formData.age}
                    onChange={handleChange}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Address</Label>
                <div className="relative">
                  <MapPin className="absolute left-4 top-4 w-5 h-5 text-muted-foreground" />
                  <Textarea
                    name="address"
                    placeholder="Enter your full address"
                    value={formData.address}
                    onChange={handleChange}
                    className="pl-12 min-h-[100px]"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Current Location (City)</Label>
                <Input
                  name="currentLocation"
                  placeholder="e.g., Bangalore, Mumbai, Delhi"
                  value={formData.currentLocation}
                  onChange={handleChange}
                />
              </div>

              <div className="space-y-4">
                <Label className="text-base font-semibold">Are you a Student or Working Professional?</Label>
                <div className="grid grid-cols-2 gap-4">
                  <button
                    onClick={() => setUserType("student")}
                    className={`p-4 rounded-xl border-2 transition-all ${
                      userType === "student"
                        ? "border-primary bg-primary/10"
                        : "border-border hover:border-primary/50"
                    }`}
                  >
                    <GraduationCap className="w-8 h-8 mx-auto mb-2 text-primary" />
                    <p className="font-medium">Student</p>
                  </button>
                  <button
                    onClick={() => setUserType("professional")}
                    className={`p-4 rounded-xl border-2 transition-all ${
                      userType === "professional"
                        ? "border-primary bg-primary/10"
                        : "border-border hover:border-primary/50"
                    }`}
                  >
                    <Briefcase className="w-8 h-8 mx-auto mb-2 text-primary" />
                    <p className="font-medium">Professional</p>
                  </button>
                </div>
              </div>

              {userType === "professional" && (
                <div className="space-y-4 p-4 bg-muted/50 rounded-xl">
                  <div className="space-y-2">
                    <Label>Work Experience (Years)</Label>
                    <Input
                      name="workExperience"
                      placeholder="e.g., 3 years"
                      value={formData.workExperience}
                      onChange={handleChange}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Past Job Roles</Label>
                    <Textarea
                      name="pastRoles"
                      placeholder="e.g., Software Developer at TCS, Marketing Manager at Infosys"
                      value={formData.pastRoles}
                      onChange={handleChange}
                    />
                  </div>
                </div>
              )}

              <Button
                variant="hero"
                size="lg"
                className="w-full"
                onClick={() => setStep(2)}
                disabled={!userType}
              >
                Continue
                <ArrowRight className="w-5 h-5" />
              </Button>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6">
              <h2 className="text-xl font-bold flex items-center gap-2">
                <GraduationCap className="w-5 h-5 text-primary" />
                Skills & Education
              </h2>

              <div className="space-y-2">
                <Label>Highest Education</Label>
                <Input
                  name="education"
                  placeholder="e.g., B.Tech in Computer Science"
                  value={formData.education}
                  onChange={handleChange}
                />
              </div>

              <div className="space-y-2">
                <Label>Qualifications / Certifications</Label>
                <Textarea
                  name="qualifications"
                  placeholder="List any certifications or qualifications"
                  value={formData.qualifications}
                  onChange={handleChange}
                />
              </div>

              <div className="space-y-3">
                <Label>Skills</Label>
                <div className="flex flex-wrap gap-2">
                  {skillOptions.map((skill) => (
                    <button
                      key={skill}
                      onClick={() => toggleArrayItem(formData.skills, skill, "skills")}
                      className={`px-3 py-1.5 rounded-full text-sm font-medium transition-all ${
                        formData.skills.includes(skill)
                          ? "gradient-primary text-primary-foreground"
                          : "bg-muted text-muted-foreground hover:bg-muted/80"
                      }`}
                    >
                      {skill}
                    </button>
                  ))}
                </div>
                <div className="flex gap-2">
                  <Input
                    placeholder="Add custom skill"
                    value={newSkill}
                    onChange={(e) => setNewSkill(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && addSkill()}
                  />
                  <Button onClick={addSkill} variant="outline">
                    Add
                  </Button>
                </div>
              </div>

              <div className="space-y-3">
                <Label className="flex items-center gap-2">
                  <Languages className="w-4 h-4" />
                  Languages
                </Label>
                <div className="flex flex-wrap gap-2">
                  {languageOptions.map((lang) => (
                    <button
                      key={lang}
                      onClick={() => toggleArrayItem(formData.languages, lang, "languages")}
                      className={`px-3 py-1.5 rounded-full text-sm font-medium transition-all ${
                        formData.languages.includes(lang)
                          ? "gradient-primary text-primary-foreground"
                          : "bg-muted text-muted-foreground hover:bg-muted/80"
                      }`}
                    >
                      {lang}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-3">
                <Label>Job Interests</Label>
                <div className="flex flex-wrap gap-2">
                  {interestOptions.map((interest) => (
                    <button
                      key={interest}
                      onClick={() => toggleArrayItem(formData.interests, interest, "interests")}
                      className={`px-3 py-1.5 rounded-full text-sm font-medium transition-all ${
                        formData.interests.includes(interest)
                          ? "gradient-primary text-primary-foreground"
                          : "bg-muted text-muted-foreground hover:bg-muted/80"
                      }`}
                    >
                      {interest}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex gap-4">
                <Button variant="outline" size="lg" onClick={() => setStep(1)} className="flex-1">
                  Back
                </Button>
                <Button
                  variant="hero"
                  size="lg"
                  className="flex-1"
                  onClick={() => {
                    setStep(3);
                    setShowMentorPopup(true);
                  }}
                >
                  Continue
                  <ArrowRight className="w-5 h-5" />
                </Button>
              </div>
            </div>
          )}

          {step === 3 && !showMentorPopup && (
            <div className="space-y-6 text-center">
              <CheckCircle className="w-20 h-20 mx-auto text-primary" />
              <h2 className="text-2xl font-bold">Almost Done!</h2>
              <p className="text-muted-foreground">Review your profile and complete setup</p>
              
              <div className="flex gap-4">
                <Button variant="outline" size="lg" onClick={() => setStep(2)} className="flex-1">
                  Back
                </Button>
                <Button variant="hero" size="lg" className="flex-1" onClick={handleSubmit} disabled={isLoading}>
                  {isLoading ? (
                    <div className="w-5 h-5 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                  ) : (
                    <>
                      Complete Setup
                      <ArrowRight className="w-5 h-5" />
                    </>
                  )}
                </Button>
              </div>
            </div>
          )}
        </div>

        {/* Mentor Popup */}
        {showMentorPopup && (
          <div className="fixed inset-0 bg-foreground/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-card rounded-3xl shadow-lg max-w-lg w-full p-8 max-h-[90vh] overflow-y-auto">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold">Do You Want a Mentor?</h3>
                <button
                  onClick={() => {
                    setShowMentorPopup(false);
                    setWantsMentor(false);
                  }}
                  className="text-muted-foreground hover:text-foreground"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {wantsMentor === null ? (
                <div className="space-y-4">
                  <p className="text-muted-foreground">
                    A mentor can guide you through career decisions, personal challenges, and help you grow.
                  </p>
                  <div className="grid grid-cols-2 gap-4">
                    <Button variant="hero" size="lg" onClick={() => setWantsMentor(true)}>
                      Yes, I want a mentor
                    </Button>
                    <Button
                      variant="outline"
                      size="lg"
                      onClick={() => {
                        setWantsMentor(false);
                        setShowMentorPopup(false);
                      }}
                    >
                      No, thanks
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="space-y-6">
                  <div className="space-y-2">
                    <Label>What problems are you currently facing?</Label>
                    <Textarea
                      name="mentorProblems"
                      placeholder="Describe your challenges..."
                      value={formData.mentorProblems}
                      onChange={handleChange}
                      className="min-h-[100px]"
                    />
                  </div>

                  <div className="space-y-3">
                    <Label>What guidance do you need?</Label>
                    <div className="flex flex-wrap gap-2">
                      {guidanceOptions.map((guide) => (
                        <button
                          key={guide}
                          onClick={() => toggleArrayItem(formData.mentorGuidance, guide, "mentorGuidance")}
                          className={`px-3 py-1.5 rounded-full text-sm font-medium transition-all ${
                            formData.mentorGuidance.includes(guide)
                              ? "gradient-primary text-primary-foreground"
                              : "bg-muted text-muted-foreground hover:bg-muted/80"
                          }`}
                        >
                          {guide}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Tell us more about your situation (optional)</Label>
                    <Textarea
                      name="mentorDetails"
                      placeholder="Any additional details that would help us match you with the right mentor..."
                      value={formData.mentorDetails}
                      onChange={handleChange}
                      className="min-h-[120px]"
                    />
                  </div>

                  <Button
                    variant="hero"
                    size="lg"
                    className="w-full"
                    onClick={() => setShowMentorPopup(false)}
                  >
                    Save & Continue
                  </Button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProfileSetup;
