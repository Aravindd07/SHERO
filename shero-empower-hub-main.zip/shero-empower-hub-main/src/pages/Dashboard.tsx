import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import Logo from "@/components/Logo";
import SOSButton from "@/components/SOSButton";
import { supabase } from "@/integrations/supabase/client";
import {
  Briefcase,
  User,
  BookOpen,
  Users,
  MessageCircle,
  MapPin,
  ArrowRight,
  LogOut,
  Star,
  Shield,
  Sparkles,
  Heart,
  TrendingUp,
  Clock,
} from "lucide-react";

interface Mentor {
  id: string;
  name: string;
  role: string;
  image_url: string;
  rating: number;
}

interface Community {
  id: string;
  name: string;
  member_count: number;
  image_url: string;
}

const Dashboard = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState<any>(null);
  const [mentors, setMentors] = useState<Mentor[]>([]);
  const [communities, setCommunities] = useState<Community[]>([]);
  const [greeting, setGreeting] = useState("");

  useEffect(() => {
    const userData = localStorage.getItem("shero_user");
    if (userData) {
      setUser(JSON.parse(userData));
    } else {
      navigate("/auth");
    }
    fetchMentors();
    fetchCommunities();
    setGreeting(getGreeting());
  }, [navigate]);

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "Good Morning";
    if (hour < 17) return "Good Afternoon";
    return "Good Evening";
  };

  const fetchMentors = async () => {
    const { data } = await supabase.from('mentors').select('*').limit(3);
    if (data) setMentors(data);
  };

  const fetchCommunities = async () => {
    const { data } = await supabase.from('communities').select('*').limit(4);
    if (data) setCommunities(data);
  };

  const handleLogout = () => {
    localStorage.removeItem("shero_user");
    navigate("/");
  };

  const jobs = [
    { id: 1, title: "Software Developer", company: "TCS", location: "Bangalore", salary: "₹8-12 LPA", posted: "2 days ago", type: "Full-time" },
    { id: 2, title: "Marketing Executive", company: "Infosys", location: "Bangalore", salary: "₹5-8 LPA", posted: "1 day ago", type: "Full-time" },
    { id: 3, title: "UX Designer", company: "Wipro", location: "Remote", salary: "₹6-10 LPA", posted: "3 days ago", type: "Remote" },
  ];

  const stats = [
    { icon: <Briefcase className="w-5 h-5" />, value: "150+", label: "Jobs Available" },
    { icon: <Users className="w-5 h-5" />, value: "3.2K+", label: "Community Members" },
    { icon: <Heart className="w-5 h-5" />, value: "50+", label: "Expert Mentors" },
    { icon: <Shield className="w-5 h-5" />, value: "24/7", label: "SOS Support" },
  ];

  if (!user) return null;

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Navigation */}
      <nav className="sticky top-0 z-40 bg-card/80 backdrop-blur-lg border-b border-border">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Logo size="sm" />
          <div className="flex items-center gap-2">
            <Link to="/profile">
              <Button variant="ghost" size="sm" className="gap-2">
                <div className="w-8 h-8 rounded-full gradient-primary flex items-center justify-center text-primary-foreground text-sm font-bold">
                  {user.name?.charAt(0) || "S"}
                </div>
                <span className="hidden sm:inline">{user.name?.split(' ')[0] || "Profile"}</span>
              </Button>
            </Link>
            <Button variant="ghost" size="icon" onClick={handleLogout} className="text-muted-foreground hover:text-destructive">
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 gradient-soft opacity-50" />
        <div className="relative container mx-auto px-4 py-10">
          <div className="flex items-center gap-2 text-muted-foreground text-sm mb-2">
            <Sparkles className="w-4 h-4 text-accent" />
            <span>{greeting}</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold mb-3">
            Welcome back, <span className="text-gradient">{user.name?.split(' ')[0] || "SHERO"}!</span>
          </h1>
          <p className="text-muted-foreground text-lg">Your journey to success continues today</p>
          
          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
            {stats.map((stat, index) => (
              <div 
                key={index} 
                className="bg-card/60 backdrop-blur-sm p-4 rounded-2xl border border-border/50 text-center hover:border-primary/30 transition-all hover:-translate-y-1"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="w-10 h-10 mx-auto mb-2 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
                  {stat.icon}
                </div>
                <p className="text-2xl font-bold text-gradient">{stat.value}</p>
                <p className="text-xs text-muted-foreground">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <div className="container mx-auto px-4 py-8 space-y-10">
        {/* Quick Actions */}
        <section>
          <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-primary" />
            Quick Access
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { icon: <Briefcase className="w-6 h-6" />, label: "Find Jobs", desc: "150+ openings", path: "/jobs", gradient: "from-blue-500 to-cyan-500" },
              { icon: <Users className="w-6 h-6" />, label: "Mentors", desc: "Get guidance", path: "/mentors", gradient: "from-purple-500 to-pink-500" },
              { icon: <BookOpen className="w-6 h-6" />, label: "Courses", desc: "Learn skills", path: "/courses", gradient: "from-orange-500 to-amber-500" },
              { icon: <MessageCircle className="w-6 h-6" />, label: "Community", desc: "Join discussions", path: "/community", gradient: "from-green-500 to-emerald-500" },
            ].map((item, index) => (
              <Link
                key={index}
                to={item.path}
                className="group relative bg-card p-5 rounded-2xl border border-border hover:border-primary/50 transition-all hover:-translate-y-1 hover:shadow-soft overflow-hidden"
              >
                <div className={`absolute inset-0 bg-gradient-to-br ${item.gradient} opacity-0 group-hover:opacity-5 transition-opacity`} />
                <div className={`w-12 h-12 mb-4 rounded-xl bg-gradient-to-br ${item.gradient} flex items-center justify-center text-white group-hover:scale-110 transition-transform`}>
                  {item.icon}
                </div>
                <p className="font-bold">{item.label}</p>
                <p className="text-xs text-muted-foreground">{item.desc}</p>
              </Link>
            ))}
          </div>
        </section>

        {/* Jobs Preview */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold flex items-center gap-2">
              <Briefcase className="w-5 h-5 text-primary" />
              Latest Job Opportunities
            </h2>
            <Link to="/jobs">
              <Button variant="ghost" size="sm" className="gap-1 text-primary">
                View All <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          </div>
          <div className="grid gap-4">
            {jobs.map((job, index) => (
              <div 
                key={job.id} 
                className="bg-card p-5 rounded-2xl border border-border hover:border-primary/30 transition-all hover:shadow-soft group"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-bold text-lg group-hover:text-primary transition-colors">{job.title}</h3>
                      <span className="px-2 py-0.5 text-xs bg-primary/10 text-primary rounded-full">{job.type}</span>
                    </div>
                    <p className="text-muted-foreground">{job.company}</p>
                    <div className="flex flex-wrap items-center gap-4 mt-3 text-sm">
                      <span className="flex items-center gap-1 text-muted-foreground">
                        <MapPin className="w-4 h-4" />{job.location}
                      </span>
                      <span className="flex items-center gap-1 text-muted-foreground">
                        <Clock className="w-4 h-4" />{job.posted}
                      </span>
                      <span className="font-semibold text-primary">{job.salary}</span>
                    </div>
                  </div>
                  <Button variant="outline" size="sm" className="shrink-0 group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                    Apply
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Mentors */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold flex items-center gap-2">
              <Heart className="w-5 h-5 text-primary" />
              Featured Mentors
            </h2>
            <Link to="/mentors">
              <Button variant="ghost" size="sm" className="gap-1 text-primary">
                View All <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          </div>
          <div className="grid md:grid-cols-3 gap-4">
            {mentors.map((mentor) => (
              <Link 
                key={mentor.id} 
                to="/mentors"
                className="bg-card p-6 rounded-2xl border border-border text-center hover:border-primary/30 transition-all hover:-translate-y-1 hover:shadow-soft group"
              >
                <div className="relative w-24 h-24 mx-auto mb-4">
                  <img 
                    src={mentor.image_url} 
                    alt={mentor.name} 
                    className="w-full h-full rounded-full object-cover border-4 border-primary/20 group-hover:border-primary/50 transition-colors" 
                  />
                  <div className="absolute -bottom-1 -right-1 w-8 h-8 rounded-full bg-accent flex items-center justify-center text-accent-foreground">
                    <Star className="w-4 h-4 fill-current" />
                  </div>
                </div>
                <h3 className="font-bold text-lg">{mentor.name}</h3>
                <p className="text-sm text-muted-foreground mb-2">{mentor.role}</p>
                <div className="flex items-center justify-center gap-1 text-accent">
                  <Star className="w-4 h-4 fill-current" />
                  <span className="font-semibold">{mentor.rating}</span>
                </div>
              </Link>
            ))}
          </div>
        </section>

        {/* Communities */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold flex items-center gap-2">
              <MessageCircle className="w-5 h-5 text-primary" />
              Active Communities
            </h2>
            <Link to="/community">
              <Button variant="ghost" size="sm" className="gap-1 text-primary">
                View All <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          </div>
          <div className="grid md:grid-cols-2 gap-4">
            {communities.slice(0, 2).map((community) => (
              <Link
                key={community.id}
                to="/community"
                className="relative bg-card rounded-2xl border border-border overflow-hidden hover:border-primary/30 transition-all hover:shadow-soft group"
              >
                <div className="absolute inset-0">
                  <img 
                    src={community.image_url} 
                    alt={community.name}
                    className="w-full h-full object-cover opacity-20 group-hover:opacity-30 transition-opacity"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-card via-card/80 to-transparent" />
                </div>
                <div className="relative p-6">
                  <h3 className="font-bold text-lg mb-1">{community.name}</h3>
                  <p className="text-sm text-muted-foreground flex items-center gap-1">
                    <Users className="w-4 h-4" />
                    {community.member_count?.toLocaleString()} members
                  </p>
                  <Button variant="hero" size="sm" className="mt-4">
                    Join Community
                  </Button>
                </div>
              </Link>
            ))}
          </div>
        </section>

        {/* Safety Banner */}
        <section className="relative overflow-hidden">
          <div className="gradient-primary rounded-3xl p-8 text-primary-foreground">
            <div className="flex flex-col md:flex-row items-center gap-6">
              <div className="w-20 h-20 rounded-2xl bg-white/20 flex items-center justify-center shrink-0">
                <Shield className="w-10 h-10" />
              </div>
              <div className="flex-1 text-center md:text-left">
                <h3 className="text-2xl font-bold mb-2">Your Safety is Our Priority</h3>
                <p className="opacity-90">Voice-activated SOS, instant alerts, and 24/7 emergency support. You're never alone with SHERO.</p>
              </div>
              <Link to="/sos-setup" className="shrink-0">
                <Button variant="outline" className="bg-white/20 border-white/30 text-white hover:bg-white/30">
                  Setup SOS Contact
                </Button>
              </Link>
            </div>
          </div>
        </section>
      </div>

      <SOSButton sosNumber={user.sosNumber} />
    </div>
  );
};

export default Dashboard;