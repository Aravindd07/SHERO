import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import Logo from "@/components/Logo";
import { toast } from "@/hooks/use-toast";
import { Phone, Shield, AlertTriangle, ArrowRight, CheckCircle, MessageCircle } from "lucide-react";

const SOSSetup = () => {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [sosNumber, setSOSNumber] = useState("");
  const [emergencyName, setEmergencyName] = useState("");

  const handleSubmit = () => {
    if (!sosNumber || sosNumber.length < 10) {
      toast({
        title: "Invalid Phone Number",
        description: "Please enter a valid 10-digit phone number",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);

    setTimeout(() => {
      const userData = JSON.parse(localStorage.getItem("shero_user") || "{}");
      userData.sosNumber = sosNumber;
      userData.emergencyName = emergencyName;
      userData.setupComplete = true;
      localStorage.setItem("shero_user", JSON.stringify(userData));

      toast({
        title: "SOS Setup Complete! 🛡️",
        description: "Your emergency contact has been saved. You're all set!",
      });

      setIsLoading(false);
      navigate("/dashboard");
    }, 1500);
  };

  return (
    <div className="min-h-screen gradient-soft p-4">
      <div className="container mx-auto max-w-lg py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <Logo size="md" />
          <h1 className="text-3xl font-bold mt-6 mb-2">SOS Emergency Setup</h1>
          <p className="text-muted-foreground">Add your trusted contact for emergencies</p>
        </div>

        {/* Main Card */}
        <div className="bg-card rounded-3xl shadow-soft p-8 border border-border">
          {/* Warning Banner */}
          <div className="flex items-start gap-3 p-4 bg-destructive/10 rounded-xl mb-8">
            <AlertTriangle className="w-6 h-6 text-destructive flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-semibold text-destructive">Important Safety Feature</h3>
              <p className="text-sm text-muted-foreground">
                This number will be contacted immediately in case of an emergency. Make sure it's someone you trust.
              </p>
            </div>
          </div>

          <div className="space-y-6">
            <div className="space-y-2">
              <Label>Emergency Contact Name</Label>
              <Input
                placeholder="e.g., Mom, Dad, Best Friend"
                value={emergencyName}
                onChange={(e) => setEmergencyName(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label>Emergency Phone Number</Label>
              <div className="relative">
                <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  type="tel"
                  placeholder="+91 XXXXX XXXXX"
                  value={sosNumber}
                  onChange={(e) => setSOSNumber(e.target.value)}
                  className="pl-12"
                />
              </div>
            </div>

            {/* SOS Features Info */}
            <div className="space-y-3 p-4 bg-muted/50 rounded-xl">
              <h4 className="font-semibold">When SOS is triggered:</h4>
              <ul className="space-y-2">
                {[
                  { icon: <Phone className="w-4 h-4" />, text: "Auto-call to your emergency contact" },
                  { icon: <MessageCircle className="w-4 h-4" />, text: "SMS & WhatsApp alert sent" },
                  { icon: <Shield className="w-4 h-4" />, text: "Live location shared" },
                ].map((item, index) => (
                  <li key={index} className="flex items-center gap-3 text-sm">
                    <span className="text-primary">{item.icon}</span>
                    {item.text}
                  </li>
                ))}
              </ul>
            </div>

            <Button
              variant="hero"
              size="lg"
              className="w-full"
              onClick={handleSubmit}
              disabled={isLoading}
            >
              {isLoading ? (
                <div className="w-5 h-5 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
              ) : (
                <>
                  Complete Setup
                  <CheckCircle className="w-5 h-5" />
                </>
              )}
            </Button>

            <button
              onClick={() => navigate("/dashboard")}
              className="w-full text-center text-sm text-muted-foreground hover:text-foreground"
            >
              Skip for now (not recommended)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SOSSetup;
