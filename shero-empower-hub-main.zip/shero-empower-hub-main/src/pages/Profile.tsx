import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import Logo from "@/components/Logo";
import {
  User,
  Mail,
  Phone,
  MapPin,
  GraduationCap,
  Briefcase,
  Languages,
  Shield,
  Edit,
  ArrowLeft,
  CheckCircle,
} from "lucide-react";

const Profile = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    const userData = localStorage.getItem("shero_user");
    if (userData) {
      setUser(JSON.parse(userData));
    } else {
      navigate("/auth");
    }
  }, [navigate]);

  if (!user) {
    return null;
  }

  const profile = user.profile || {};

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="gradient-primary py-8 px-4">
        <div className="container mx-auto max-w-2xl">
          <Link to="/dashboard" className="inline-flex items-center gap-2 text-primary-foreground/80 hover:text-primary-foreground mb-6">
            <ArrowLeft className="w-4 h-4" />
            Back to Dashboard
          </Link>
          
          <div className="flex items-center gap-6">
            <div className="w-24 h-24 bg-primary-foreground/20 rounded-full flex items-center justify-center">
              <User className="w-12 h-12 text-primary-foreground" />
            </div>
            <div className="text-primary-foreground">
              <h1 className="text-3xl font-bold">{user.name || "SHERO User"}</h1>
              <p className="opacity-80">{user.email}</p>
              <div className="flex items-center gap-2 mt-2">
                <CheckCircle className="w-4 h-4" />
                <span className="text-sm">Verified SHERO</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto max-w-2xl px-4 py-8 space-y-6">
        {/* Personal Info Card */}
        <div className="bg-card rounded-2xl p-6 border border-border shadow-soft">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold flex items-center gap-2">
              <User className="w-5 h-5 text-primary" />
              Personal Information
            </h2>
            <Button variant="ghost" size="sm">
              <Edit className="w-4 h-4" />
            </Button>
          </div>
          
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <Mail className="w-5 h-5 text-muted-foreground" />
              <div>
                <p className="text-sm text-muted-foreground">Email</p>
                <p className="font-medium">{user.email}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Phone className="w-5 h-5 text-muted-foreground" />
              <div>
                <p className="text-sm text-muted-foreground">Phone</p>
                <p className="font-medium">{profile.phone || "Not provided"}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <MapPin className="w-5 h-5 text-muted-foreground" />
              <div>
                <p className="text-sm text-muted-foreground">Location</p>
                <p className="font-medium">{profile.currentLocation || "Not provided"}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Education & Skills Card */}
        <div className="bg-card rounded-2xl p-6 border border-border shadow-soft">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold flex items-center gap-2">
              <GraduationCap className="w-5 h-5 text-primary" />
              Education & Skills
            </h2>
            <Button variant="ghost" size="sm">
              <Edit className="w-4 h-4" />
            </Button>
          </div>
          
          <div className="space-y-4">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Education</p>
              <p className="font-medium">{profile.education || "Not provided"}</p>
            </div>
            
            {profile.skills?.length > 0 && (
              <div>
                <p className="text-sm text-muted-foreground mb-2">Skills</p>
                <div className="flex flex-wrap gap-2">
                  {profile.skills.map((skill: string, index: number) => (
                    <span
                      key={index}
                      className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm font-medium"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            )}
            
            {profile.languages?.length > 0 && (
              <div>
                <p className="text-sm text-muted-foreground mb-2 flex items-center gap-1">
                  <Languages className="w-4 h-4" />
                  Languages
                </p>
                <div className="flex flex-wrap gap-2">
                  {profile.languages.map((lang: string, index: number) => (
                    <span
                      key={index}
                      className="px-3 py-1 bg-muted text-muted-foreground rounded-full text-sm font-medium"
                    >
                      {lang}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Work Experience Card */}
        {profile.workExperience && (
          <div className="bg-card rounded-2xl p-6 border border-border shadow-soft">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold flex items-center gap-2">
                <Briefcase className="w-5 h-5 text-primary" />
                Work Experience
              </h2>
              <Button variant="ghost" size="sm">
                <Edit className="w-4 h-4" />
              </Button>
            </div>
            
            <div className="space-y-4">
              <div>
                <p className="text-sm text-muted-foreground">Experience</p>
                <p className="font-medium">{profile.workExperience}</p>
              </div>
              {profile.pastRoles && (
                <div>
                  <p className="text-sm text-muted-foreground">Past Roles</p>
                  <p className="font-medium">{profile.pastRoles}</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* SOS Contact Card */}
        <div className="bg-destructive/10 rounded-2xl p-6 border border-destructive/20">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold flex items-center gap-2 text-destructive">
              <Shield className="w-5 h-5" />
              Emergency Contact
            </h2>
            <Button variant="ghost" size="sm" className="text-destructive">
              <Edit className="w-4 h-4" />
            </Button>
          </div>
          
          <div className="space-y-2">
            <p className="font-medium">{user.emergencyName || "Emergency Contact"}</p>
            <p className="text-muted-foreground">{user.sosNumber || "Not set up"}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
